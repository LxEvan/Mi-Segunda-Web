import { Component, OnInit, Input, Output } from '@angular/core';

@Component({
  selector: 'app-modificareventos',
  templateUrl: './modificareventos.component.html',
  styleUrls: ['./modificareventos.component.css']
})
export class ModificareventosComponent implements OnInit {

  
  constructor() { }
 

  ngOnInit(): void {
  }

}
