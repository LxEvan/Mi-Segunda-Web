import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ModificareventosComponent } from './modificareventos.component';

describe('ModificareventosComponent', () => {
  let component: ModificareventosComponent;
  let fixture: ComponentFixture<ModificareventosComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ModificareventosComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ModificareventosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
