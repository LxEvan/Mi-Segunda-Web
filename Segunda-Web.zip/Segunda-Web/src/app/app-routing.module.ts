import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EventosComponent } from './eventos/eventos.component';
import { AltaeventosComponent } from './altaeventos/altaeventos.component';
import { ModificareventosComponent } from './modificareventos/modificareventos.component';
import { HeaderComponent } from './header/header.component';
import { InicioComponent } from './inicio/inicio.component';

const routes: Routes = [
  {path: 'eventos', component: EventosComponent},
  {path: 'altaeventos', component: AltaeventosComponent},
  {path: 'modificareventos', component: ModificareventosComponent},
  {path: 'header', component: HeaderComponent},
  {path: 'inicio', component: InicioComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
