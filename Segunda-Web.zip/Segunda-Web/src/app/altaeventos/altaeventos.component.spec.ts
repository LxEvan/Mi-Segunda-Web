import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AltaeventosComponent } from './altaeventos.component';

describe('AltaeventosComponent', () => {
  let component: AltaeventosComponent;
  let fixture: ComponentFixture<AltaeventosComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AltaeventosComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AltaeventosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
