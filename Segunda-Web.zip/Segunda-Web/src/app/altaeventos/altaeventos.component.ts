import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-altaeventos',
  templateUrl: './altaeventos.component.html',
  styleUrls: ['./altaeventos.component.css']
})
export class AltaeventosComponent implements OnInit {

  lista:string[]=[];
  constructor() { }
  
  addEvento(newEvento){
    this.lista.push(newEvento.value);
    return false;
  }
  elimEvento(lista){
    for(let x=0;  x<this.lista.length; x++){
      if(lista == this.lista[x]){
        this.lista.splice (x,1)
      }
    }
  }

  ngOnInit(): void {
  }

}
